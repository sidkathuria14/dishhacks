# SIH_2018_Linguistic_Pandas
Our project for Smart India Hackathon 2018 contributed by a team of 6 geeks.
<br/>
**please keep adding your views in this file**
<br/>
Taks to-do:
<br/>
1. Get api's of reddit, twitter, quora to fetch tweets/content to be analysed in the later part
<br/>
2. Gather a training set with tweets/content with their sentiments analysed to be used as a training set
<br/>
3. Use word2vec and other NLP tools to gather insights from the fetched content
<br/>
4. Apply supervised learning models to train our model

<br/>
<br/>

**Potential solutions for sentimental analysis that have excellent, and proven results**

https://github.com/cbaziotis/datastories-semeval2017-task4
https://github.com/bfelbo/DeepMoji

**Working**
<br/>
1. We input modi in our system
<br/>
2.It gathers material from the 3 social netwroking handles and using word2ves gathers the top 3 related content related to it.
<br/>
Let's say the three keyqords came as : PM Modi, Nirav Modi, Modi sarkar
<br/>
3. Now, user selects the desired keyword and then our system fetches a large amount of tweets/content and analyses sentiments in it and shows the insights of the results generated.

<br/>
Ab kaam start karo nhi toh train ticket cancel karo :P
